from __future__ import unicode_literals

from django.apps import AppConfig


class TsdConfig(AppConfig):
    name = 'tsd'
